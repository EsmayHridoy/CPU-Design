If you add components, I would be glad if you would send
me the new components so I can add them to the library.
In this way, the library becomes more and more complete over time.

Just open a GitHub issue and attach the new components or
send a pull request (https://github.com/hneemann/Digital).
